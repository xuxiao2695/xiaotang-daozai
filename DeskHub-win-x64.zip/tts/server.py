"""Local Chinese TTS for DeskHub: Fun-CosyVoice3-0.5B on the GPU behind a tiny HTTP server.

POST /tts    (body: UTF-8 text)        -> audio/wav   ?instruct=请用四川话表达。  ?voice=<another voice>
GET  /health                           -> 200 once the model is loaded
GET  /voice                            -> name of the active voice ("" = default)
GET  /style, POST /style (body)        -> how to speak, e.g. 请用陕西话表达。 ("" = plain); used when /tts has no ?instruct=
POST /voice  (body: voice folder name) -> switch voice (empty body = default)

Voices are cloned from a short reference recording plus its transcript, see VOICES below.
"""
import io
import os
import sys
import threading
import time
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
COSY = os.path.join(HERE, "CosyVoice")
sys.path[:0] = [COSY, os.path.join(COSY, "third_party", "Matcha-TTS")]

import numpy as np  # noqa: E402
import torch  # noqa: E402
from cosyvoice.cli.cosyvoice import AutoModel  # noqa: E402

PORT = int(os.environ.get("DESKHUB_TTS_PORT", "47802"))
MODEL_DIR = os.path.join(COSY, "pretrained_models", "Fun-CosyVoice3-0.5B")
PROMPT_HEADER = "You are a helpful assistant.<|endofprompt|>"

# Voices: tts\voices\<name>\voice.wav + voice.txt (what is said in it). "" = the sample voice
# shipped with CosyVoice. The active one is remembered in tts\voices\active.txt.
VOICES = os.path.join(HERE, "voices")
ACTIVE_FILE = os.path.join(VOICES, "active.txt")
DEFAULT_WAV = os.path.join(COSY, "asset", "zero_shot_prompt.wav")
DEFAULT_TEXT = "希望你以后能够做的比我还好呦。"

t0 = time.time()
# fp16 measured slower than fp32 on the RTX 3090 (and loads far slower), so it is off by default
model = AutoModel(model_dir=MODEL_DIR, fp16=os.environ.get("DESKHUB_TTS_FP16", "0") == "1")
lock = threading.Lock()
loaded = set()  # voice names already turned into speaker embeddings
active = ""


def voice_files(name: str):
    """(sample wav, what is said in it) for a voice; "" = the built-in sample voice."""
    if not name:
        return DEFAULT_WAV, DEFAULT_TEXT
    folder = os.path.join(VOICES, name)
    return os.path.join(folder, "voice.wav"), open(os.path.join(folder, "voice.txt"), encoding="utf-8").read().strip()


def load_voice(name: str):
    """Clone a voice once (call with the lock held)."""
    if name not in loaded:
        wav, text = voice_files(name)
        model.add_zero_shot_spk(PROMPT_HEADER + text, wav, "v:" + name)
        loaded.add(name)


def use_voice(name: str):
    """Make a voice the one used for speech."""
    global active
    with lock:
        load_voice(name)
        active = name
    os.makedirs(VOICES, exist_ok=True)
    with open(ACTIVE_FILE, "w", encoding="utf-8") as f:
        f.write(name)


# How to say things (CosyVoice3 instruct mode), e.g. "请用陕西话表达。"; "" = plain. Kept in style.txt.
STYLE_FILE = os.path.join(VOICES, "style.txt")
style = open(STYLE_FILE, encoding="utf-8").read().strip() if os.path.exists(STYLE_FILE) else ""


def set_style(s: str):
    global style
    style = s.strip()
    os.makedirs(VOICES, exist_ok=True)
    with open(STYLE_FILE, "w", encoding="utf-8") as f:
        f.write(style)


saved = open(ACTIVE_FILE, encoding="utf-8").read().strip() if os.path.exists(ACTIVE_FILE) else ""
try:
    use_voice(saved)
except Exception as e:  # a voice folder that went missing: fall back to the default
    print(f"voice '{saved}' failed ({e}), using the default", flush=True)
    use_voice("")


def synthesize(text: str, instruct: str = None, voice: str = None) -> bytes:
    """voice: a voice other than the active one (e.g. to preview); instruct: how to say it, e.g.
    "请用陕西话表达。" or "请用温柔的语气说。" (CosyVoice3 instruct mode: dialects, emotion, speed)."""
    with lock:
        name = active if voice is None else voice
        instruct = style if instruct is None else instruct
        if instruct:
            wav, _ = voice_files(name)
            out = model.inference_instruct2(text, "You are a helpful assistant. " + instruct + "<|endofprompt|>", wav, stream=False)
        else:
            load_voice(name)
            out = model.inference_zero_shot(text, "", "", zero_shot_spk_id="v:" + name, stream=False)
        parts = [o["tts_speech"] for o in out]
    audio = torch.cat(parts, dim=1).squeeze(0).cpu().numpy()
    pcm = (np.clip(audio, -1, 1) * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(model.sample_rate)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


synthesize("你好。", instruct="")  # warm-up
print(f"ready in {time.time() - t0:.1f}s on {'cuda' if torch.cuda.is_available() else 'cpu'}", flush=True)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path in ("/voice", "/style"):
            body = (active if self.path == "/voice" else style).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(200 if self.path == "/health" else 404)
        self.end_headers()

    def do_POST(self):
        if self.path == "/style":  # body: instruction, empty = plain
            set_style(self.rfile.read(int(self.headers.get("Content-Length", 0))).decode("utf-8"))
            print(f"style -> '{style}'", flush=True)
            self.send_response(200)
            self.end_headers()
            return
        if self.path == "/voice":  # body: voice folder name, empty = default
            name = self.rfile.read(int(self.headers.get("Content-Length", 0))).decode("utf-8").strip()
            try:
                loaded.discard(name)  # the folder may have been re-recorded under the same name
                use_voice(name)
                print(f"voice -> '{name}'", flush=True)
                self.send_response(200)
                self.end_headers()
            except Exception as e:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(str(e).encode())
            return
        from urllib.parse import urlsplit, parse_qs
        url = urlsplit(self.path)
        q = {k: v[0] for k, v in parse_qs(url.query, keep_blank_values=True).items()}
        if url.path != "/tts":
            self.send_response(404)
            self.end_headers()
            return
        text = self.rfile.read(int(self.headers.get("Content-Length", 0))).decode("utf-8").strip()
        t = time.time()
        try:
            wav = synthesize(text, q.get("instruct"), q.get("voice"))
        except Exception as e:  # report, don't crash the server
            self.send_response(500)
            self.end_headers()
            self.wfile.write(str(e).encode())
            return
        print(f"{len(text)} chars -> {(len(wav) - 44) / 2 / model.sample_rate:.1f}s audio in {time.time() - t:.2f}s", flush=True)
        self.send_response(200)
        self.send_header("Content-Type", "audio/wav")
        self.send_header("Content-Length", str(len(wav)))
        self.end_headers()
        self.wfile.write(wav)


ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
